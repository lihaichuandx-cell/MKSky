from pathlib import Path
import math
import sys

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch
from matplotlib.ticker import LogLocator, NullFormatter, PercentFormatter
from openpyxl import load_workbook


if len(sys.argv) < 2:
    raise SystemExit("usage: generate_paper_figures.py <output_dir> [workbook_root] [panel_output_dir]")

OUT = Path(sys.argv[1])
OUT.mkdir(parents=True, exist_ok=True)
DATA_ROOT = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).resolve().parents[1] / "data" / "workbooks"
EXPERIMENT_OUT = Path(sys.argv[3]) if len(sys.argv) > 3 else OUT / "experiment_panels"
EXPERIMENT_OUT.mkdir(parents=True, exist_ok=True)

COLORS = {"MKSky": "#0072B2", "SkyCell-G": "#D55E00", "SkyAlign-R": "#009E73"}
MARKERS = {"MKSky": "o", "SkyCell-G": "s", "SkyAlign-R": "^"}
HATCHES = {"MKSky": "", "SkyCell-G": "///", "SkyAlign-R": "xx"}
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"],
    "font.size": 8.5,
    "axes.titlesize": 9.5,
    "axes.labelsize": 8.5,
    "legend.fontsize": 8.0,
    "xtick.labelsize": 8.0,
    "ytick.labelsize": 8.0,
    "axes.linewidth": 0.7,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def save(fig, name, tight=True):
    bbox = "tight" if tight else None
    fig.savefig(OUT / f"{name}.png", dpi=360, bbox_inches=bbox, facecolor="white")
    fig.savefig(OUT / f"{name}.pdf", bbox_inches=bbox, facecolor="white")
    plt.close(fig)


def find_xlsx(*parts):
    matches = []
    for path in DATA_ROOT.rglob("*.xlsx"):
        text = str(path)
        if all(part in text for part in parts):
            matches.append(path)
    if len(matches) != 1:
        raise RuntimeError(f"Expected one workbook for {parts}, found {matches}")
    return matches[0]


def values(path):
    ws = load_workbook(path, data_only=True, read_only=True).active
    return [[cell for cell in row] for row in ws.iter_rows(values_only=True)]


def numeric_row(rows, label, occurrence=0):
    found = [row for row in rows if row and row[0] == label]
    row = found[occurrence]
    return [float(value) for value in row[1:] if isinstance(value, (int, float))]


def style_axis(ax, log=True):
    if log:
        ax.set_yscale("log")
        ax.yaxis.set_minor_locator(LogLocator(base=10, subs=(2, 5)))
        ax.yaxis.set_minor_formatter(NullFormatter())
    ax.grid(True, which="major", color="#D9DEE3", linewidth=0.55, alpha=0.9)
    ax.grid(True, which="minor", color="#EDF0F2", linewidth=0.35, alpha=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(direction="out", length=3, width=0.7)


def set_log_limits(ax, series, lower_pad=1.45, upper_pad=1.65):
    positive = [value for values_ in series for value in values_ if value > 0]
    if not positive:
        return
    ax.set_ylim(min(positive) / lower_pad, max(positive) * upper_pad)


def export_axis_pdf(fig, ax, filename, legend=False):
    legend_artist = None
    remove_legend_after_export = False
    if legend:
        legend_artist = ax.get_legend()
        if legend_artist is None:
            handles, labels = ax.get_legend_handles_labels()
            if handles:
                legend_artist = ax.legend(handles, labels, loc="best", frameon=False, fontsize=7.2)
                remove_legend_after_export = True
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bbox = ax.get_tightbbox(renderer).transformed(fig.dpi_scale_trans.inverted())
    bbox = bbox.expanded(1.06, 1.10)
    fig.savefig(EXPERIMENT_OUT / filename, bbox_inches=bbox, facecolor="white")
    if legend_artist is not None and remove_legend_after_export:
        legend_artist.remove()


def plot_algorithms(ax, x, rows, occurrence=0):
    for algorithm in ("MKSky", "SkyCell-G", "SkyAlign-R"):
        y = numeric_row(rows, algorithm, occurrence)
        ax.plot(x, y, color=COLORS[algorithm], marker=MARKERS[algorithm],
                linewidth=1.55 if algorithm == "MKSky" else 1.15,
                markersize=3.8, label=algorithm)


POINTS = {
    "a": (1, 7), "b": (2, 4), "c": (5, 2), "d": (7, 1),
    "e": (2, 8), "f": (3, 6), "g": (4, 5), "h": (5, 7),
    "i": (6, 4), "j": (7, 6), "k": (8, 3), "l": (4, 8),
}
SKYLINE = {"a", "b", "c", "d"}
LABEL_OFFSETS = {
    "a": (-0.26, 0.18), "b": (-0.30, 0.18), "c": (-0.30, 0.18),
    "d": (-0.28, 0.18), "e": (0.12, 0.10), "f": (0.12, 0.10),
    "g": (-0.16, 0.30), "h": (0.12, 0.10), "i": (0.12, 0.10),
    "j": (-0.34, 0.24), "k": (0.12, 0.10), "l": (0.16, -0.28),
}


def draw_hotel_points(ax, names=None, removed=None, show_frontier=False):
    names = set(POINTS) if names is None else set(names)
    removed = set() if removed is None else set(removed)
    for name, (x, y) in POINTS.items():
        if name not in names:
            continue
        dx, dy = LABEL_OFFSETS[name]
        if name in removed:
            ax.scatter(x, y, s=40, marker="x", color="#A8ADB3", linewidth=1.0, zorder=3)
            ax.text(x + dx, y + dy, name, fontsize=8.6, color="#8A9096")
        elif name in SKYLINE:
            ax.scatter(x, y, s=48, facecolor="#222222", edgecolor="#222222", zorder=4)
            ax.text(x + dx, y + dy, name, fontsize=8.8, weight="bold")
        else:
            ax.scatter(x, y, s=42, facecolor="white", edgecolor="#333333", linewidth=1.0, zorder=3)
            ax.text(x + dx, y + dy, name, fontsize=8.6)
    if show_frontier:
        ordered = [POINTS[key] for key in ("a", "b", "c", "d")]
        x = [p[0] for p in ordered] + [8.45]
        y = [p[1] for p in ordered] + [p[1] for p in ordered][-1:]
        ax.step(x, y, where="post", color="#222222", linewidth=1.05, zorder=2)
    ax.set_xlim(0.5, 8.7)
    ax.set_ylim(0.5, 8.7)
    ax.set_xticks(range(1, 9))
    ax.set_yticks(range(1, 9))
    ax.grid(True, color="#D9DDE1", linewidth=0.55)
    ax.spines[["top", "right"]].set_visible(False)
    ax.set_xlabel("Distance to beach")
    ax.set_aspect("equal", adjustable="box")


def hotel_figure():
    fig, ax = plt.subplots(figsize=(5.50, 4.00))
    draw_hotel_points(ax, show_frontier=True)
    ax.set_ylabel("Price")
    # Equal data-unit scaling is required here: one unit on x and y must occupy
    # the same physical distance so the decision space is not visually distorted.
    ax.set_aspect("equal", adjustable="box")
    ax.annotate("b dominates g", xy=(4.06, 5.03), xytext=(5.02, 5.42),
                arrowprops=dict(arrowstyle="->", color="#555555", lw=0.8,
                                shrinkA=3, shrinkB=5),
                fontsize=8.2, ha="left")
    fig.subplots_adjust(left=0.16, right=0.94, bottom=0.16, top=0.96)
    save(fig, "fig01_hotel", tight=False)


def add_box(ax, xy, width, height, text, face, edge="#465563", fontsize=9, weight="normal"):
    box = FancyBboxPatch(xy, width, height, boxstyle="round,pad=0.015,rounding_size=0.025",
                         facecolor=face, edgecolor=edge, linewidth=1.0)
    ax.add_patch(box)
    ax.text(xy[0] + width / 2, xy[1] + height / 2, text, ha="center", va="center",
            fontsize=fontsize, weight=weight, color="#23313D")
    return box


def orth_arrow(ax, points, color="#465563", lw=1.0, linestyle="-"):
    xs, ys = zip(*points)
    ax.plot(xs, ys, color=color, lw=lw, linestyle=linestyle, solid_capstyle="butt", zorder=2)
    ax.annotate("", xy=points[-1], xytext=points[-2],
                arrowprops=dict(arrowstyle="->", color=color, lw=lw, shrinkA=0, shrinkB=0))


def branch_down(ax, source, targets, junction_y, color="#465563", lw=0.9):
    sx, sy = source
    ax.plot([sx, sx], [sy, junction_y], color=color, lw=lw)
    left = min(x for x, _ in targets)
    right = max(x for x, _ in targets)
    ax.plot([left, right], [junction_y, junction_y], color=color, lw=lw)
    for tx, ty in targets:
        ax.annotate("", xy=(tx, ty), xytext=(tx, junction_y),
                    arrowprops=dict(arrowstyle="->", color=color, lw=lw, shrinkA=0, shrinkB=0))


def stage_box(ax, x, y, w, h, title, purpose, lines, face):
    ax.add_patch(Rectangle((x, y), w, h, facecolor="white", edgecolor="#42515E", lw=1.05, zorder=1))
    ax.plot([x, x + w], [y + h - 0.56, y + h - 0.56], color="#42515E", lw=0.9)
    ax.text(x + w / 2, y + h - 0.28, title, ha="center", va="center",
            fontsize=8.6, weight="bold", color="#1F2D38")
    ax.text(x + w / 2, y + h - 0.75, purpose, ha="center", va="center",
            fontsize=7.3, color="#596975", style="italic")
    inner_h = (h - 1.35) / len(lines)
    top = y + h - 0.97
    for i, line in enumerate(lines):
        iy = top - (i + 1) * inner_h
        add_box(ax, (x + 0.22, iy), w - 0.44, inner_h - 0.12, line, face,
                edge="#8293A1", fontsize=8.0)


def flow_figure():
    # Match the final Word width so font sizes are not reduced during insertion.
    fig, ax = plt.subplots(figsize=(6.25, 3.65))
    ax.set_xlim(0, 15.2); ax.set_ylim(0, 9.2); ax.axis("off")
    stage_box(ax, 2.7, 5.25, 4.6, 3.15,
              "Stage 1: Candidate reduction",
              "Reduce downstream work",
              ["Choose pruning route",
               "Grid / real-pivot pruning",
               "Mark, scan, compact"], "#E4F0EA")
    stage_box(ax, 9.15, 5.25, 4.6, 3.15,
              "Stage 2: Ordered layout",
              "Build contiguous access order",
              ["Quantize coordinates",
               "Morton code + radix sort",
               "Reorder coordinates"], "#E3ECF6")
    stage_box(ax, 9.15, 0.75, 4.6, 3.15,
              "Stage 3: MKD partitioning",
              "Bound local comparisons",
              ["Choose target block size",
               "Endpoint XOR/MSB split",
               "Prefix-local filtering + compact"], "#E3ECF6")
    stage_box(ax, 2.7, 0.75, 4.6, 3.15,
              "Stage 4: Filter and verify",
              "Avoid full-coordinate reads",
              ["Block Min-Corner filter",
               "Optional safe summaries",
               "Exact check + tail check"], "#F5E6E5")
    ax.add_patch(Rectangle((0.10, 6.12), 2.05, 1.35, fc="white", ec="#42515E", lw=1.0))
    ax.text(1.125, 6.90, "Dataset P", ha="center", va="center", fontsize=8.8, weight="bold")
    ax.text(1.125, 6.53, "n points, d dims", ha="center", va="center", fontsize=7.0, color="#596975")
    ax.add_patch(Rectangle((0.10, 1.55), 2.05, 1.20, fc="white", ec="#42515E", lw=1.0))
    ax.text(1.125, 2.27, "Skyline S", ha="center", va="center", fontsize=8.8, weight="bold")
    ax.text(1.125, 1.88, "original indices", ha="center", va="center", fontsize=7.0, color="#596975")
    orth_arrow(ax, [(2.15, 6.80), (2.7, 6.80)])
    orth_arrow(ax, [(7.3, 6.80), (9.15, 6.80)])
    ax.text(8.22, 7.10, r"No: output $P^{\prime}$", ha="center", fontsize=7.2, color="#315C7C",
            bbox=dict(fc="white", ec="none", pad=1.4))
    orth_arrow(ax, [(11.45, 5.25), (11.45, 3.90)])
    ax.text(11.68, 4.58, "Morton-ordered\ncoordinates", ha="left", va="center",
            fontsize=7.1, color="#315C7C", bbox=dict(fc="white", ec="none", pad=0.6))
    orth_arrow(ax, [(9.15, 2.30), (7.30, 2.30)])
    ax.text(8.22, 2.57, r"$P^{\prime\prime}$ + block IDs", ha="center", fontsize=7.2, color="#315C7C",
            bbox=dict(fc="white", ec="none", pad=0.7))
    orth_arrow(ax, [(2.70, 2.15), (2.15, 2.15)])
    add_box(ax, (3.05, 4.35), 3.90, 0.55, r"$d \leq 4$, $|P^{\prime}| \leq 5000$?", "#F7EDD2",
             edge="#B48A2B", fontsize=8.2, weight="bold")
    orth_arrow(ax, [(5.00, 5.25), (5.00, 4.90)], color="#B48A2B", lw=0.9, linestyle="--")
    orth_arrow(ax, [(3.05, 4.625), (2.35, 4.625), (2.35, 2.80), (2.15, 2.80)],
               color="#B48A2B", lw=0.9, linestyle="--")
    ax.text(0.35, 4.05, "Yes: exact verification", ha="left", va="center",
            fontsize=7.1, color="#7A5B18",
            bbox=dict(fc="white", ec="none", pad=0.7))
    ax.text(7.6, 0.25,
            "Optional branches change workload; final decisions use exact coordinates.",
            ha="center", fontsize=7.0, color="#596975")
    fig.tight_layout(pad=0.2)
    save(fig, "fig02_flow")


def prefilter_figure():
    removed = {"e", "f", "g", "h", "i", "j", "l"}
    kept = set(POINTS) - removed
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.65), sharex=False, sharey=False)
    draw_hotel_points(axes[0], removed=removed)
    axes[0].add_patch(Rectangle((2, 4), 6.55, 4.55, facecolor="#BFC5CA", alpha=0.16,
                                edgecolor="#777777", linestyle="--", linewidth=0.9))
    axes[0].scatter(*POINTS["b"], s=74, facecolor="#222222", edgecolor="white", linewidth=0.7, zorder=5)
    axes[0].annotate("real pivot b", xy=POINTS["b"], xytext=(3.0, 3.15),
                     arrowprops=dict(arrowstyle="->", lw=.8, color="#555555"), fontsize=8.0)
    axes[0].set_title("(a) Safe pruning by a real pivot", pad=6)
    axes[0].set_ylabel("Price")
    draw_hotel_points(axes[1], names=kept)
    axes[1].set_ylabel("Price")
    axes[1].set_title("(b) Compact candidate set P'", pad=6)
    axes[1].text(4.7, 8.15, "P' = {a, b, c, d, k}", ha="center", va="center", fontsize=8.2,
                 bbox=dict(boxstyle="round,pad=.22", fc="white", ec="#777777"))
    fig.tight_layout(w_pad=1.8)
    save(fig, "fig03_prefilter")


def morton_mkd_figure():
    ordered = [("b", 11, "001011"), ("c", 18, "010010"), ("d", 20, "010100"),
               ("k", 29, "011101"), ("a", 40, "101000")]
    # A slightly taller layout keeps the partition hierarchy legible at journal width
    # and avoids an awkward page break before the next method subsection.
    fig, ax = plt.subplots(figsize=(9.2, 5.8))
    ax.set_xlim(0, 10.5); ax.set_ylim(0, 6.7); ax.axis("off")
    ax.text(0.3, 6.30, "Morton-ordered candidate array (original coordinates are retained)",
            fontsize=9.0, weight="bold", color="#273746")
    x0, w, gap = 0.45, 1.55, 0.34
    for i, (name, code, bits) in enumerate(ordered):
        x = x0 + i * (w + gap)
        add_box(ax, (x, 5.15), w, 0.78, f"{name}: {bits} ({code})", "#E6EDF4", fontsize=8.1)
    add_box(ax, (1.1, 3.88), 7.15, 0.72,
            "[b, c, d, k, a]   11 XOR 40 = 35   highest differing bit = 5", "#F3E9D2", fontsize=8.2)
    orth_arrow(ax, [(4.65, 5.15), (4.65, 4.60)])
    add_box(ax, (0.75, 2.62), 6.20, 0.68,
            "[b, c, d, k]   11 XOR 29 = 22   highest differing bit = 4", "#F3E9D2", fontsize=8.0)
    add_box(ax, (7.75, 2.62), 1.55, 0.68, "[a]", "#E4F0EA", fontsize=8.2, weight="bold")
    branch_down(ax, (4.68, 3.88), [(3.85, 3.30), (8.53, 3.30)], 3.55)
    add_box(ax, (0.55, 1.45), 1.55, 0.65, r"$C_1=[b]$", "#E4F0EA", fontsize=8.1, weight="bold")
    add_box(ax, (2.35, 1.45), 2.55, 0.65, "[c, d, k]   18 XOR 29 = 15 (bit 3)", "#F3E9D2", fontsize=7.6)
    add_box(ax, (7.75, 1.45), 1.55, 0.65, r"$C_4=[a]$", "#E4F0EA", fontsize=8.1, weight="bold")
    branch_down(ax, (3.85, 2.62), [(1.33, 2.10), (3.63, 2.10)], 2.35)
    orth_arrow(ax, [(8.53, 2.62), (8.53, 2.10)])
    add_box(ax, (2.25, 0.30), 1.75, 0.65, r"$C_2=[c,d]$", "#E4F0EA", fontsize=8.1, weight="bold")
    add_box(ax, (4.45, 0.30), 1.55, 0.65, r"$C_3=[k]$", "#E4F0EA", fontsize=8.1, weight="bold")
    branch_down(ax, (3.63, 1.45), [(3.13, 0.95), (5.23, 0.95)], 1.18)
    ax.text(6.2, 0.52, "Target block size = 2; only [start, end) is stored.", fontsize=7.8, color="#596975")
    save(fig, "fig04_morton_mkd")


def filter_figure():
    # Keep the plot free of sentence-length annotations; the right panel uses a
    # single vertical decision chain so labels and connectors cannot intersect.
    fig, axes = plt.subplots(1, 2, figsize=(7.15, 3.45), gridspec_kw={"width_ratios": [1.0, 1.22]})
    ax = axes[0]
    ax.set_xlim(0.5, 8.7); ax.set_ylim(0.5, 5.6)
    ax.set_xticks(range(1, 9)); ax.set_yticks(range(1, 6))
    ax.grid(True, color="#D9DDE1", lw=0.5); ax.spines[["top", "right"]].set_visible(False)
    ax.set_xlabel("Distance to beach"); ax.set_ylabel("Price")
    ax.set_title("(a) Block test", pad=5, fontsize=8.7)
    ax.scatter(2, 4, s=48, facecolor="white", edgecolor="#222222", zorder=4)
    ax.text(2.10, 4.10, "b", fontsize=8.5)
    ax.text(1.10, 4.46, r"$C_1=\{b\}$", fontsize=7.6, color="#596975")
    ax.text(1.10, 3.68, r"$\mathrm{MC}_1=(2,4)$", fontsize=7.6, color="#596975")
    ax.scatter([5, 7], [2, 1], s=48, facecolor="#222222", edgecolor="#222222", zorder=4)
    ax.text(4.72, 2.18, "c", fontsize=8.5, weight="bold"); ax.text(6.72, 1.18, "d", fontsize=8.5, weight="bold")
    ax.scatter(8, 3, s=58, marker="D", facecolor="white", edgecolor="#B04A3A", linewidth=1.3, zorder=5)
    ax.text(8.12, 3.12, "k", fontsize=8.2, color="#8E352A", weight="bold")
    ax.scatter(5, 1, s=55, marker="s", facecolor="white", edgecolor="#315C7C", linewidth=1.2, zorder=5)
    ax.text(4.10, 0.72, r"$\mathrm{MC}_2=(5,1)$", fontsize=7.8, color="#315C7C")
    ax.add_patch(Rectangle((5, 1), 2, 1, fill=False, edgecolor="#315C7C", linestyle="--", linewidth=0.9))
    ax.text(5.55, 2.10, r"$C_2=\{c,d\}$", fontsize=7.4, color="#315C7C")
    ax = axes[1]
    ax.set_xlim(0, 7); ax.set_ylim(0, 7.5); ax.axis("off")
    ax.set_title("(b) Verification path", pad=5, fontsize=8.7)
    center_x = 3.5
    box_x, box_w, box_h = 0.85, 5.30, 0.72
    y_values = [6.30, 5.15, 4.00, 2.85, 1.70, 0.55]
    texts = [
        "candidate k = (8,3)",
        r"$\mathrm{MC}_1=(2,4)$; price 4 > 3",
        r"$C_1$ cannot contain a dominator; skip it",
        r"$\mathrm{MC}_2=(5,1) \preceq k$; exclusion fails",
        r"read original coordinates in $C_2$",
        r"$c=(5,2) \prec k$; remove k",
    ]
    faces = ["#E3ECF6", "#E4F0EA", "#E4F0EA", "#F3E9D2", "#F5E6E5", "#F5E6E5"]
    weights = ["bold", "normal", "normal", "normal", "normal", "bold"]
    for y, text_value, face, weight in zip(y_values, texts, faces, weights):
        add_box(ax, (box_x, y), box_w, box_h, text_value, face,
                fontsize=7.25, weight=weight)
    for upper, lower in zip(y_values, y_values[1:]):
        orth_arrow(ax, [(center_x, upper), (center_x, lower + box_h)])
    fig.tight_layout(w_pad=1.65)
    save(fig, "fig05_filter_verify")


def scale_figure(dim, name):
    if dim == 6:
        specs = [("Independent", ("6维", "独立分布")),
                 ("Correlated", ("6维", "正相关")),
                 ("Anti-correlated", ("6维", "反相关"))]
        xlabels = ["0.1M", "0.5M", "1M", "5M", "10M", "30M"]
    else:
        specs = [("Independent", ("3维测试", "独立分布")),
                 ("Correlated", ("3维测试", "正相关")),
                 ("Anti-correlated", ("3维测试", "反相关"))]
        xlabels = ["0.1M", "0.5M", "1M", "5M", "10M", "30M"]
    sizes = [1e5, 5e5, 1e6, 5e6, 1e7, 3e7]
    fig, axes = plt.subplots(1, 3, figsize=(9.2, 3.1), sharey=False)
    panel_names = ["左_独立分布", "中_正相关", "右_反相关"]
    for ax, (title, parts) in zip(axes, specs):
        rows = values(find_xlsx(*parts))
        plot_algorithms(ax, sizes, rows, 0)
        style_axis(ax, True)
        panel_series = [numeric_row(rows, algorithm, 0) for algorithm in ("MKSky", "SkyCell-G", "SkyAlign-R")]
        set_log_limits(ax, panel_series)
        ax.set_xscale("log")
        ax.set_title(title)
        ax.set_xticks(sizes, xlabels, rotation=0)
        ax.set_xlabel("Number of points")
        ax.set_ylabel("GPU algorithm time (s, log scale)")
    if dim == 3:
        anti_rows = values(find_xlsx(*specs[2][1]))
        final_ratio = numeric_row(anti_rows, "SkyCell-G", 0)[-1] / numeric_row(anti_rows, "MKSky", 0)[-1]
        axes[2].text(0.04, 0.95, f"SkyCell-G / MKSky at 30M: {final_ratio:.2f}×",
                     transform=axes[2].transAxes, ha="left", va="top", fontsize=7.0,
                     color="#596975", bbox=dict(fc="white", ec="#D9DEE3", pad=1.8))
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.tight_layout(rect=(0, .08, 1, 1), w_pad=1.5)
    figure_no = 6 if dim == 6 else 7
    descriptor = "6维数据规模扩展性" if dim == 6 else "3维数据规模扩展性"
    for ax, panel_name in zip(axes, panel_names):
        export_axis_pdf(fig, ax, f"图{figure_no}_{descriptor}_{panel_name}.pdf", legend=True)
    save(fig, name)


def dimension_figure():
    specs = [("Independent", "独立分布"), ("Correlated", "正相关"), ("Anti-correlated", "反相关")]
    dims = [3, 4, 5, 6, 7, 8, 10, 12, 16]
    fig, axes = plt.subplots(1, 3, figsize=(9.2, 3.1), sharey=False)
    panel_names = ["左_独立分布", "中_正相关", "右_反相关"]
    for ax, (title, distribution) in zip(axes, specs):
        rows = values(find_xlsx("6维", distribution))
        plot_algorithms(ax, dims, rows, 1)
        style_axis(ax, True)
        panel_series = [numeric_row(rows, algorithm, 1) for algorithm in ("MKSky", "SkyCell-G", "SkyAlign-R")]
        set_log_limits(ax, panel_series)
        ax.set_title(title); ax.set_xticks(dims); ax.set_xlabel("Dimensionality d")
        ax.set_ylabel("GPU algorithm time (s, log scale)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.tight_layout(rect=(0, .08, 1, 1), w_pad=1.5)
    for ax, panel_name in zip(axes, panel_names):
        export_axis_pdf(fig, ax, f"图8_维度扩展性_{panel_name}.pdf", legend=True)
    save(fig, "fig08_dimension")


def ablation_figure():
    dim_rows = values(find_xlsx("消融实验", "维度变化"))
    scale_rows = values(find_xlsx("消融实验", "规模变化"))
    dims = [3, 4, 5, 6, 7, 8, 10, 12]
    sizes = [5e4, 1e5, 5e5, 1e6, 5e6, 1e7, 3e7]
    size_labels = ["0.05M", "0.1M", "0.5M", "1M", "5M", "10M", "30M"]
    fig, axes = plt.subplots(1, 2, figsize=(8.7, 3.25), sharey=False)
    labels = ["MKSky", "Without auxiliary summaries", "Without block skipping", "Fixed-size chunks"]
    colors = ["#0072B2", "#CC6677", "#7B61A8", "#8C6D31"]
    markers = ["o", "s", "^", "D"]
    dim_values = [[float(row[column]) for row in dim_rows[2:10] if row[0]] for column in range(1, 5)]
    scale_values = [[float(row[column]) for row in scale_rows[2:9] if row[0]] for column in range(1, 5)]
    for series, label, color, marker in zip(dim_values, labels, colors, markers):
        axes[0].plot(dims, series, label=label, color=color, marker=marker, lw=1.35, ms=3.8)
    for series, label, color, marker in zip(scale_values, labels, colors, markers):
        axes[1].plot(sizes, series, label=label, color=color, marker=marker, lw=1.35, ms=3.8)
    axes[0].set_title("Varying dimensionality (n = 5M)"); axes[0].set_xlabel("Dimensionality d"); axes[0].set_xticks(dims)
    axes[1].set_title("Varying data size (d = 8)"); axes[1].set_xlabel("Number of points")
    axes[1].set_xscale("log"); axes[1].set_xticks(sizes, size_labels)
    for ax in axes: style_axis(ax, True)
    set_log_limits(axes[0], dim_values)
    set_log_limits(axes[1], scale_values)
    for ax in axes: ax.set_ylabel("GPU algorithm time (s, log scale)")
    handles, leglabels = axes[0].get_legend_handles_labels()
    fig.legend(handles, leglabels, loc="lower center", ncol=3, frameon=False, bbox_to_anchor=(0.5, -0.01))
    fig.tight_layout(rect=(0, .10, 1, 1), w_pad=1.8)
    export_axis_pdf(fig, axes[0], "图9_消融实验_左_维度变化.pdf", legend=True)
    export_axis_pdf(fig, axes[1], "图9_消融实验_右_规模变化.pdf", legend=True)
    save(fig, "fig09_ablation")


def work_figure():
    rows = values(find_xlsx("假阳性", "显存占用"))
    body = [row for row in rows if row[0] and str(row[0]).lower().endswith("d")]
    dims = [int(str(row[0])[:-1]) for row in body]
    pre = [float(row[1]) for row in body]
    candidates = [float(row[2]) for row in body]
    trigger = [float(row[5]) for row in body]
    selected = [i for i, d in enumerate(dims) if d >= 5]
    full_dims = [dims[i] for i in selected]
    pre_rate = [pre[i] / 5_000_000 * 100 for i in selected]
    local_rate = [candidates[i] / 5_000_000 * 100 for i in selected]
    exact_rate = [trigger[i] * 100 for i in selected]
    fig, axes = plt.subplots(1, 2, figsize=(8.7, 3.25))
    axes[0].plot(full_dims, pre_rate, color="#7A8793", marker="s", lw=1.2, label="After pre-pruning")
    axes[0].plot(full_dims, local_rate, color="#0072B2", marker="o", lw=1.5, label="After prefix-local filtering")
    axes[0].set_ylim(0, 105)
    axes[0].set_title("Candidate retention under the full path")
    axes[0].set_xlabel("Dimensionality d"); axes[0].set_ylabel("Retained candidates (%)")
    axes[0].set_xticks(full_dims)
    axes[0].grid(True, axis="y", color="#E3E7EA", lw=.5)
    axes[0].spines[["top", "right"]].set_visible(False)
    # Keep both processing-path labels visible without hiding the curves.
    axes[0].legend(
        frameon=True,
        facecolor="white",
        edgecolor="none",
        framealpha=0.88,
        loc="upper left",
        bbox_to_anchor=(0.015, 0.985),
        borderaxespad=0.0,
        fontsize=7.2,
    )
    bars = axes[1].bar(full_dims, exact_rate, width=0.62, color="#D9E7F1",
                       edgecolor="#315C7C", linewidth=0.8)
    for bar, rate in zip(bars, exact_rate):
        axes[1].text(bar.get_x() + bar.get_width() / 2, rate + max(exact_rate) * 0.025,
                     f"{rate:.2f}", ha="center", va="bottom", fontsize=7.0, color="#315C7C")
    axes[1].set_ylim(0, max(exact_rate) * 1.22)
    axes[1].set_title("Exact-verification entry rate")
    axes[1].set_xlabel("Dimensionality d"); axes[1].set_ylabel("Entry rate (%)")
    axes[1].set_xticks(full_dims)
    axes[1].grid(True, axis="y", color="#E3E7EA", lw=.5)
    axes[1].spines[["top", "right"]].set_visible(False)
    axes[1].text(0.98, 0.95, "d >= 5: identical processing path", transform=axes[1].transAxes,
                 ha="right", va="top", fontsize=7.3, color="#596975")
    fig.tight_layout(w_pad=2.0)
    export_axis_pdf(fig, axes[0], "图10_过滤工作量_左_候选保留率.pdf", legend=True)
    export_axis_pdf(fig, axes[1], "图10_过滤工作量_右_精确验证进入率.pdf", legend=False)
    save(fig, "fig10_filter_work")


def memory_time_figure():
    rows = values(find_xlsx("假阳性", "显存占用"))
    body = [row for row in rows if row[0] and str(row[0]).lower().endswith("d")]
    dims = [int(str(row[0])[:-1]) for row in body]
    memory = {
        "MKSky": [float(row[7]) for row in body],
        "SkyCell-G": [float(row[8]) for row in body],
        "SkyAlign-R": [float(row[9]) for row in body],
    }
    time_rows = values(find_xlsx("6维", "反相关"))
    all_dims = [3, 4, 5, 6, 7, 8, 10, 12, 16]
    times = {
        algorithm: [numeric_row(time_rows, algorithm, 1)[all_dims.index(d)] for d in dims]
        for algorithm in memory
    }
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.25))
    bar_width = 0.22
    for offset, algorithm in zip((-bar_width, 0, bar_width), memory):
        axes[0].bar([d + offset for d in dims], memory[algorithm], width=bar_width,
                    color=COLORS[algorithm], alpha=0.82, hatch=HATCHES[algorithm],
                    edgecolor="#374151", linewidth=0.45, label=algorithm)
        axes[1].plot(dims, times[algorithm], color=COLORS[algorithm], marker=MARKERS[algorithm], lw=1.3, ms=3.8, label=algorithm)
    axes[0].set_title("Peak device memory"); axes[0].set_xlabel("Dimensionality d"); axes[0].set_ylabel("Memory (MB)")
    axes[0].set_xticks(dims)
    axes[0].grid(True, color="#E3E7EA", lw=.5); axes[0].spines[["top", "right"]].set_visible(False)
    axes[1].set_title("Execution time for the same inputs"); axes[1].set_xlabel("Dimensionality d"); axes[1].set_ylabel("GPU algorithm time (s, log scale)")
    style_axis(axes[1], True)
    set_log_limits(axes[1], list(times.values()))
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, frameon=False, bbox_to_anchor=(0.5, -0.01))
    fig.tight_layout(rect=(0, .10, 1, 1), w_pad=2.0)
    export_axis_pdf(fig, axes[0], "图11_显存与时间_左_峰值显存.pdf", legend=True)
    export_axis_pdf(fig, axes[1], "图11_显存与时间_右_运行时间.pdf", legend=True)
    save(fig, "fig11_memory_time")


def cpu_gpu_figure():
    rows = values(find_xlsx("CPU基线测试"))
    labels = ["50k", "100k", "500k", "1M", "5M", "10M"]
    sizes = [5e4, 1e5, 5e5, 1e6, 5e6, 1e7]
    cpu = [float(row[1]) for row in rows[2:8]]
    gpu = [float(row[2]) for row in rows[2:8]]
    fig, ax = plt.subplots(figsize=(6.7, 3.5))
    ax.plot(sizes, cpu, color="#CC6677", marker="s", lw=1.4, label="CPU-SFS")
    ax.plot(sizes, gpu, color="#0072B2", marker="o", lw=1.6, label="MKSky")
    style_axis(ax, True)
    ax.set_xscale("log")
    ax.set_xticks(sizes, labels)
    ax.set_xlabel("Number of points"); ax.set_ylabel("Execution time (s, log scale)")
    ax.set_title("Single-thread CPU-SFS vs MKSky (d=8, anti-correlated)")
    ax.legend(frameon=False)
    set_log_limits(ax, [cpu, gpu])
    export_axis_pdf(fig, ax, "图12_CPU基线对比.pdf", legend=True)
    save(fig, "fig12_cpu_gpu")


def stage_figure(distribution_cn, title, name):
    rows = values(find_xlsx("局部", distribution_cn))
    dims = [3, 4, 5, 6, 7, 8, 10, 12, 16]
    data = {}
    for algorithm in ("MKSky", "SkyCell-G", "SkyAlign-R"):
        matches = [row for row in rows if row and row[0] == algorithm]
        vals = []
        for row in matches:
            vals.extend(float(v) for v in row[1:] if isinstance(v, (int, float)))
        data[algorithm] = (vals[0::2], vals[1::2])
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.25), sharey=False)
    width = 0.22
    for offset, (algorithm, (pre, core)) in zip((-width, 0, width), data.items()):
        axes[0].bar([d + offset for d in dims], pre, width=width,
                    color=COLORS[algorithm], alpha=0.84, hatch=HATCHES[algorithm],
                    edgecolor="#374151", linewidth=0.45, label=algorithm)
        axes[1].bar([d + offset for d in dims], core, width=width,
                    color=COLORS[algorithm], alpha=0.84, hatch=HATCHES[algorithm],
                    edgecolor="#374151", linewidth=0.45, label=algorithm)
    for ax, subtitle in zip(axes, ["Preprocessing", "Candidate verification"]):
        style_axis(ax, True); ax.set_title(subtitle); ax.set_xlabel("Dimensionality d")
        ax.set_xticks(dims)
        ax.set_ylabel("Time (s, log scale)")
    set_log_limits(axes[0], [values_[0] for values_ in data.values()])
    set_log_limits(axes[1], [values_[1] for values_ in data.values()])
    fig.suptitle(title, y=1.01, fontsize=9.5)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, frameon=False, bbox_to_anchor=(0.5, -0.01))
    fig.tight_layout(rect=(0, .10, 1, .98), w_pad=1.8)
    figure_map = {
        "fig13_stage_correlated": (13, "正相关阶段耗时"),
        "fig14_stage_independent": (14, "独立分布阶段耗时"),
        "fig15_stage_anti": (15, "反相关阶段耗时"),
    }
    figure_no, descriptor = figure_map[name]
    export_axis_pdf(fig, axes[0], f"图{figure_no}_{descriptor}_左_前处理.pdf", legend=True)
    export_axis_pdf(fig, axes[1], f"图{figure_no}_{descriptor}_右_候选验证.pdf", legend=True)
    save(fig, name)


def main():
    hotel_figure()
    flow_figure()
    prefilter_figure()
    morton_mkd_figure()
    filter_figure()
    scale_figure(6, "fig06_scale_6d")
    scale_figure(3, "fig07_scale_3d")
    dimension_figure()
    ablation_figure()
    work_figure()
    memory_time_figure()
    cpu_gpu_figure()
    stage_figure("正相关", "Correlated data (n = 5M)", "fig13_stage_correlated")
    stage_figure("独立分布", "Independent data (n = 5M)", "fig14_stage_independent")
    stage_figure("反相关", "Anti-correlated data (n = 5M)", "fig15_stage_anti")
    print(f"generated figures in {OUT}")


if __name__ == "__main__":
    main()
