# Follow-up experiments for the red-team revision

This directory contains the raw CSV outputs added in response to the
pre-submission review. All benchmark runs used the Release x64 executable,
one warmup, and correctness checking. The manuscript reports
`algorithm_avg_ms` as device-resident GPU time and reports
`end_to_end_avg_ms` separately.

## Directory map

- `skycell_anchor/`: author-source SkyCell 3D anchor and the local
  `SkyCell-G` runs on the same input coordinates. The `layer_check/` files
  record the exactness sweep used to select layer 2. Author and local timers
  have different boundaries, so the manuscript does not calculate a speedup
  between them.
- `order/`: generated, shuffled, first-coordinate-sorted, and
  coordinate-sum-sorted inputs. The CSV files record the selected route,
  candidate counts, output count, GPU time, and adapter time.
- `ablation/`: independent removal of candidate reduction and local prefix
  filtering. The small exact-reference files check output-index equality.
- `sensitivity/`: one-factor changes to the direct-verification threshold,
  target chunk capacity, auxiliary-summary threshold, and compatibility
  threshold. Targeted runs use ten measured repetitions. The
  `*_exact20k.csv` files verify chunk-capacity variants against the exact CPU
  result.
- `end_to_end/`: three representative configurations used to separate
  device-resident algorithm time from one-pass adapter time.

## Reproduction notes

The executable and option definitions are in `../../code/`. In particular:

- `--input-csv` loads a shared coordinate file for source-to-reproduction
  anchors.
- `--input-order generated|shuffled|sorted-d0|sorted-sum` controls the order
  test.
- `--mksky-disable-candidate-reduction` and
  `--mksky-disable-local-prefix` select the two independent ablations.
- `--mksky-direct-limit`, `--mksky-chunk-size`,
  `--mksky-aux-threshold`, and `--mksky-compat-limit` select the sensitivity
  points.

The frozen algorithm path, generator formulas, baseline identities, ablation
definitions, and timing boundaries are specified in
`../../code/SUBMISSION_PROTOCOL.md`.
